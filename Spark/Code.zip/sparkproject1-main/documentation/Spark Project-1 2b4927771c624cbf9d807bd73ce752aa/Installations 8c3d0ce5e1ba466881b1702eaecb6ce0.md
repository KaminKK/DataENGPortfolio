# Installations

Apache Spark in local can be installed via 

- Docker (Recommended)
- Brew (only for mac users)
- Jar given in spark site. ([https://spark.apache.org/downloads.html](https://spark.apache.org/downloads.html))

## Using Docker:

## prerequisite:

Install Docker Desktop. ([https://hub.docker.com/editions/community/docker-ce-desktop-mac](https://hub.docker.com/editions/community/docker-ce-desktop-mac)) 

- Run below command to download the docker image.

```bash
**docker pull bitnami/spark:3.0.1**
```

- Start the container in detach mode

```bash
**docker run --volume=<Your local path>:/data  -d --name spark bitnami/spark:3.0.1**

example: docker run --volume=/Users/sri/Desktop:/data  -d --name spark bitnami/spark:3.0.1
```

## Verify

```bash
**docker exec -it spark spark-shell**

output:
To adjust logging level use sc.setLogLevel(newLevel). For SparkR, use setLogLevel(newLevel).
Spark context Web UI available at http://dd4953c3f191:4040
Spark context available as 'sc' (master = local[*], app id = local-1635404754195).
Spark session available as 'spark'.
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /___/ .__/\_,_/_/ /_/\_\  
      /_/

Using Scala version 2.12.10 (OpenJDK 64-Bit Server VM, Java 1.8.0_292)
Type in expressions to have them evaluated.
Type :help for more information.
-------------------------------------------------------------------------

**Run these bold commands:**

scala> **val textFile = spark.read.textFile("README.md")**
textFile: org.apache.spark.sql.Dataset[String] = [value: string]

scala> **textFile.count()** // Number of items in this Dataset
res0: Long = 126 // May be different from yours as README.md will change over time, similar to other outputs

scala> **textFile.first()** // First item in this Dataset
res1: String = # Apache Spark
```

## Using Brew Command:

Follow this blog: [https://notadatascientist.com/install-spark-on-macos/](https://notadatascientist.com/install-spark-on-macos/)

## Using jar :

- Go to link [https://spark.apache.org/downloads.html](https://spark.apache.org/downloads.html)
- Select the version of the spark under **Choose a Spark release .** Recommend you to select version 3.0.3.
- Select the version of package type as **Pre-Built for Apache Hadoop 2.7**
- Click on [spark-3.0.3-bin-hadoop2.7.tgz](https://www.apache.org/dyn/closer.lua/spark/spark-3.0.3/spark-3.0.3-bin-hadoop2.7.tgz) to Download the zip file.
- Once downloaded, in local unzip the jar and its ready for using !

> **Note: Spark 3.0+ is pre-built with Scala 2.12.**
> 

## Verify

- Start the spark shell. Run the command from the root of the spark library.
    
    ```bash
    **./bin/spark-shell**
    ```
    
    It should start a spark-shell successfully with out any error.  
    
    For double check, run the below code.
    
    ```bash
    scala> val textFile = spark.read.textFile("README.md")
    textFile: org.apache.spark.sql.Dataset[String] = [value: string]
    
    scala> textFile.count() // Number of items in this Dataset
    res0: Long = 126 // May be different from yours as README.md will change over time, similar to other outputs
    
    scala> textFile.first() // First item in this Dataset
    res1: String = # Apache Spark
    ```
    

## Troubleshoot

- To stop a docker container: **docker stop <container_name>**
- To remove a dead container : **docker rm <container_name>**
- To get out of container shell : **ctrl+c or ctrl+d**