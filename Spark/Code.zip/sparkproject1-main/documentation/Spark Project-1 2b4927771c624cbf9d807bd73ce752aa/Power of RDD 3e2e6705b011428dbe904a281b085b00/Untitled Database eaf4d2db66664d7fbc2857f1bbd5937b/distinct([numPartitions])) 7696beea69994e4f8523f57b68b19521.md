# distinct([numPartitions]))

Explanation: Return a new dataset that contains the distinct elements of the source dataset