# Configurations

## Overview

Spark properties control most application settings and are configured separately for each application. These properties can be set directly on a [SparkConf](https://spark.apache.org/docs/latest/api/scala/org/apache/spark/SparkConf.html) passed to via 

- Inside Application by creaging SparkConf object
- Dynamically passing the configuration flags while submitting the Job.
- Creating **conf/spark-defaults.conf** and passing the conf variables here.

Few instances of how configurations play in the application behaviour.

- Setting more executor memory than default so that jobs can run faster.
- Setting the threshold on the result size of the application, so that there will not be OutOfMemoryException.
- Whether to submit the job in client mode or cluster mode.
- Setting the number of cores for driver and executors.
- Passing extra JavaOptions.

## Setting the configurations via SparkConf object

```scala
val conf = new SparkConf()
             .setMaster("local[2]")
             .setAppName("CountingSheep")
						 .set("spark.shuffle.spill.compress",true)
```

## Passing the configurations dynamically via Command  Line

In some cases, you may want to avoid hard-coding certain configurations in a `SparkConf`. For instance, if you’d like to run the same application with different masters or different amounts of memory. Spark allows you to simply create an empty conf.

Eg: 

```bash
./bin/spark-submit --name "My app" --master local[4] --conf spark.eventLog.enabled=false
  --conf "spark.executor.extraJavaOptions=-XX:+PrintGCDetails -XX:+PrintGCTimeStamps" myApp.jar
```

## Adding the configurations via conf/spark-defaults.sh

Key values should be added in new line with space between them.

```bash
spark.master            spark://5.6.7.8:7077
spark.executor.memory   4g
spark.eventLog.enabled  true
spark.serializer        org.apache.spark.serializer.KryoSerializer
```

## Precedence

Any values specified as flags or in the properties file will be passed on to the application and merged with those specified through SparkConf. Properties set directly on the **SparkConf** take highest precedence, then flags passed to `spark-submit` or `spark-shell`, then options in the `spark-defaults.conf` file.

## View the properties

The application web UI at `http://<driver>:4040` lists Spark properties in the “Environment” tab. Note that only values explicitly specified through `spark-defaults.conf`, `SparkConf`, or the command line will appear. 

## Type of Properties

- Related to Deploy. (eg: spark.driver.memory, spark.executor.instances)
- Spark Runtime control. (eg: spark.task.maxFailures)

Deploy related properties  may not be affected when setting programmatically through SparkConf in runtime.