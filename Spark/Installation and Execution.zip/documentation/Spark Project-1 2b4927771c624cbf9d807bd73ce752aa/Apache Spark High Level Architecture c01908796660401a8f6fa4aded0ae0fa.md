# Apache Spark High Level Architecture

# **Overview**

Apache spark is an open source lightning fast unified analytics engine for large scale processing and machine learning. It provides high-level APIs in Java, Scala, Python and R, and an optimized engine that supports general execution graphs.

# **Architecture**

![Apache%20Spark%20High%20Level%20Architecture%20c01908796660401a8f6fa4aded0ae0fa/Screenshot_2021-07-29_at_10.25.47_PM.png](Apache%20Spark%20High%20Level%20Architecture%20c01908796660401a8f6fa4aded0ae0fa/Screenshot_2021-07-29_at_10.25.47_PM.png)

![Apache%20Spark%20High%20Level%20Architecture%20c01908796660401a8f6fa4aded0ae0fa/Screenshot_2021-07-29_at_10.18.15_PM.png](Apache%20Spark%20High%20Level%20Architecture%20c01908796660401a8f6fa4aded0ae0fa/Screenshot_2021-07-29_at_10.18.15_PM.png)

# **Highlights of Spark**

- Speed
- Ease of Use
- A Unified Engine
- Spark Web UI (localhost:4040)

![Apache%20Spark%20High%20Level%20Architecture%20c01908796660401a8f6fa4aded0ae0fa/Screenshot_2021-07-30_at_1.11.50_PM.png](Apache%20Spark%20High%20Level%20Architecture%20c01908796660401a8f6fa4aded0ae0fa/Screenshot_2021-07-30_at_1.11.50_PM.png)

# **Core Concepts**

- DAG & Lazy Evaluation
- Transformations and actions
- RDD & Dataframe
- SparkSession

# **Reference**

[https://spark.apache.org/](https://spark.apache.org/)

[https://spark.apache.org/docs/latest/quick-start.html](https://spark.apache.org/docs/latest/quick-start.html) 

[https://www.oreilly.com/library/view/spark-the-definitive/9781491912201/](https://www.oreilly.com/library/view/spark-the-definitive/9781491912201/) 

[https://alvinalexander.com/scala/collection-scala-flatmap-examples-map-flatten/](https://alvinalexander.com/scala/collection-scala-flatmap-examples-map-flatten/) 

[https://spark.apache.org/docs/latest/configuration.html](https://spark.apache.org/docs/latest/configuration.html) 

[https://spark.apache.org/docs/latest/api/java/index.html](https://spark.apache.org/docs/latest/api/java/index.html)