# Project Setup Overview

- Like any other Java/Scala web application, spark project also can be created using Maven or SBT tools . Sbt is most preferred for its best compatibility and advance features for scala language.
- The dependencies required for coding using Spark API.
    
     
    
    ```bash
    libraryDependencies += "org.apache.spark" %% "spark-core" % "3.0.1" 
    libraryDependencies += "org.apache.spark" %% "spark-sql" % "3.0.1" 
    ```
    

> Other libraries such as spark ML, spark kafka related and many more also available in maven central.  ([https://mvnrepository.com/artifact/org.apache.spark](https://mvnrepository.com/artifact/org.apache.spark))
>