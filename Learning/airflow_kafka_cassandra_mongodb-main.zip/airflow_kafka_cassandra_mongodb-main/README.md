# Overview

![image](https://github.com/dogukannulu/airflow_kafka_cassandra_mongodb/assets/91257958/b5ffd185-e046-43cc-ace6-cb7c4069d95f)
